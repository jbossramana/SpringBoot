package demo.boot.service;

public interface CustomerIdGenerator {
    int generateNextId();
}

