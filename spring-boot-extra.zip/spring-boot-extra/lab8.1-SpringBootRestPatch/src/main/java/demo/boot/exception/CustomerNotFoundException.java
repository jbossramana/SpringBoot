package demo.boot.exception;

public class CustomerNotFoundException extends RuntimeException {

}
