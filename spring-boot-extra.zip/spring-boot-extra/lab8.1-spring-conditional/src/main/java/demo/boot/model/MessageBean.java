package demo.boot.model;

public interface MessageBean {

    String getMessage();
}
