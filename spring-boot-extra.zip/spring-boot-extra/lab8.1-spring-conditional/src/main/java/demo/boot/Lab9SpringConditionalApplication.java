package demo.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab9SpringConditionalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab9SpringConditionalApplication.class, args);
	}

}
