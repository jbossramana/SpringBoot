package demo.boot;

import java.util.List;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class LabSpringBootJpaApplication {


	
	public static void main(String[] args) {
		SpringApplication.run(LabSpringBootJpaApplication.class, args);
		
		
		
	}

}
