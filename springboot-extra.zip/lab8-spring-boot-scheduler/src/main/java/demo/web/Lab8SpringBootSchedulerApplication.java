package demo.web;

import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

@SpringBootApplication
@EnableScheduling
@EnableAsync
public class Lab8SpringBootSchedulerApplication {

	private final AsyncMethods asyncMethods;

    public Lab8SpringBootSchedulerApplication(AsyncMethods asyncMethods) {
       this.asyncMethods = asyncMethods;
    }
    
	public static void main(String[] args) {
		SpringApplication.run(Lab8SpringBootSchedulerApplication.class, args);
	}

	  @Scheduled(fixedDelayString = "3000")
	    public void doSomething() throws ExecutionException, InterruptedException {
	   System.out.println("doSomething is running! " + Thread.currentThread().getName() + " at time: " + LocalDateTime.now());
	   CompletableFuture<String> result =   asyncMethods.doSomething2();
	   System.out.println(result.get());
	    }
	  
}
 