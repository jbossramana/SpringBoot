package demo.boot.function;

import java.util.function.Function;

public class Greeter implements Function<String, String> {

    public String apply(String s) {
        return "Hello " + s + ", and welcome to Spring Cloud Function!!!";
    }
}